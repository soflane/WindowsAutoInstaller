﻿# # Self-elevate the script if required
# # Check IF the script is not already elevated 
# if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
#     if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
#      $CommandLine = "-File `"" + $MyInvocation.MyCommand.Path + "`" " + $MyInvocation.UnboundArguments
#      Start-Process -FilePath PowerShell.exe -Verb Runas -ArgumentList $CommandLine
#      Exit
#     }
#    } else {
#    }



$OriginalPref = $ProgressPreference # Default is 'Continue'
$ProgressPreference = "continue"
#$ProgressPreference = $OriginalPref

$appsToUpdate =(winget upgrade) -replace 'ΓÇª|â€¦|…',' ' | ForEach-Object {
    if($_ -match '(.+?)\s{2,}(.+?)\s+(\S+)\s+(\S+)\s+(\S+)$'){
        $Matches[1..5] -join '|'
    }
} | ConvertFrom-Csv -Delimiter '|' 


$appsToUpdate[0].'Nom'

#foreach ( $node in $appsToUpdate )
#{
#    "Application: [$node]"
#}